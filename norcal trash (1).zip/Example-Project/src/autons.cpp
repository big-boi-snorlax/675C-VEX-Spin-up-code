#include "main.h"


/////
// For instalattion, upgrading, documentations and tutorials, check out website!
// https://ez-robotics.github.io/EZ-Template/
/////


const int DRIVE_SPEED = 110; // This is 110/127 (around 87% of max speed).  We don't suggest making this 127.
                             // If this is 127 and the robot tries to heading correct, it's only correcting by
                             // making one side slower.  When this is 87%, it's correcting by making one side
                             // faster and one side slower, giving better heading correction.
const int TURN_SPEED  = 90;
const int SWING_SPEED = 90;
const int BLUE = 1;
const int RED = 2;
const int ERROR = 3;


///
// Constants
///

// It's best practice to tune constants when the robot is empty and with heavier game objects, or with lifts up vs down.
// If the objects are light or the cog doesn't change much, then there isn't a concern here.

void default_constants() {
  chassis.set_slew_min_power(80, 80);
  chassis.set_slew_distance(7, 7);
  chassis.set_pid_constants(&chassis.headingPID, 11, 0, 20, 0);
  chassis.set_pid_constants(&chassis.forward_drivePID, 0.45, 0, 5, 0);
  chassis.set_pid_constants(&chassis.backward_drivePID, 0.45, 0, 5, 0);
  chassis.set_pid_constants(&chassis.turnPID, 5, 0.003, 35, 15);
  chassis.set_pid_constants(&chassis.swingPID, 7, 0, 45, 0);
}

void shoot(double x, double t1, double t2, double t3) {
  flywheel.move_velocity(600*x);
  pros::delay(t1);
  indexer.set_value(true);
  pros::delay(200);
  indexer.set_value(false);
  flywheel.move_velocity(600*x);
  pros::delay(t2);
  indexer.set_value(true);
  pros::delay(200);
  indexer.set_value(false);
  flywheel.move_velocity(600*x);
  pros::delay(t3);
  indexer.set_value(true);
  pros::delay(200);
  indexer.set_value(false);
  flywheel.move_velocity(0);
}

void pickup(double l, double t, double m, int d) {
  chassis.set_drive_pid(l, DRIVE_SPEED*m);
  intake_roller.move_velocity(200*d);
  pros::delay(t);
  chassis.wait_drive();
  intake_roller.move_velocity(0);
}

void roll(double ts, double m) {
  intake_roller.move_velocity(200*m);
  pros::delay(ts);
  intake_roller.move_velocity(0);
}

void expand(bool b) {
  expansion.set_value(b);
}


void weee(double x, double driveValue) {
  chassis.set_drive_pid(x, driveValue*DRIVE_SPEED);
  chassis.wait_drive();
}

void wooo(double x, double turnValue) {
  chassis.set_turn_pid(x, turnValue*TURN_SPEED);
  chassis.wait_drive();
}

//optical sensor functions

/*
int getRollerColor() {
  if (optic_sensor.get_proximity() < 200) {
		return 0;
	}
	double hue = optic_sensor.get_hue();
  if (hue < 260 && hue > 230) {
		return 1; // blue
  } 
  else if (hue < 30 && hue > 0) {
		return 2; // red
	} 
  else {
		return 3; // error in getting a colour
	}
	return 0; //guranteed return 🤓
}


void setRollerRed() {
	int rollerStartTime = pros::millis();
	do {
    intake_roller.move_velocity(-100);
    pros::delay(10);
  }
  while (getRollerColor() != 1 && pros::millis() - rollerStartTime < 500);
	pros::delay(100);
	intake_roller.move_velocity(0);
}

void setRollerBlue() {
	int rollerStartTime = pros::millis();
	do {
    intake_roller.move_velocity(-100);
    pros::delay(10);
  }
  while (getRollerColor() != 2 && pros::millis() - rollerStartTime < 500);
	pros::delay(100);
	intake_roller.move_velocity(0);
}
*/

void roller_only() {
  pros::lcd::set_text(1, "Autonomous");
  pros::lcd::set_text(2, "running");
  chassis.set_drive_pid(30, DRIVE_SPEED);
  chassis.wait_drive();9 
  intake_roller.move_velocity(-200);
  pros::delay(500);
  intake_roller.move_velocity(0);
  chassis.set_drive_pid(-40, DRIVE_SPEED);
  chassis.wait_drive();
}


void blue_comp_auton() {
  pros::lcd::set_text(1, "Autonomous");
  pros::lcd::set_text(2, "Running");
  indexer.set_value(false);
  weee(12, 1.);
  roll(100, 0.5);
  weee(-12, 1.);
  wooo(-126, 1.);
  weee(130, 1);
  pickup(40, 1500, 1, 1);
  wooo(-10, 1.);
  weee(-13.5, 1.);
  shoot(1, 3000, 1100, 800);
}


void red_comp_auton() {
  pros::lcd::set_text(1, "Autonomous");
  pros::lcd::set_text(2, "Running");
  indexer.set_value(false);
  weee(12, 1.);
  roll(100, 0.5);
  weee(-12, 1.);
  wooo(-126, 1.);
  weee(130, 1);
  pickup(40, 1500, 1, 1);
  wooo(-10, 1.);
  weee(-13.75, 1.);
  shoot(1, 3000, 1100, 800);
}


void blue_right_comp_auton() {
  pros::lcd::set_text(1, "Autonomous");
  pros::lcd::set_text(2, "Running");
  indexer.set_value(false);
  weee(40, 1.);
  wooo(90, 1.);
  weee(20, 0.8);
  roll(100, 0.5);
  weee(-12, 1.);
  wooo(225, 1.);
  weee(30, 1.);
  pickup(40, 1000, 0.9, 1);
  wooo(-30, 1.);
  weee(-15, 1.);
  shoot(1, 3250, 1250, 1000);
}

void red_right_comp_auton() {
  pros::lcd::set_text(1, "Autonomous");
  pros::lcd::set_text(2, "Running");
  indexer.set_value(false);
  weee(40, 1.);
  wooo(90, 1.);
  weee(20, 0.8);
  roll(100, 0.5);
  weee(-12, 1.);
  wooo(225, 1.);
  weee(30, 1.);
  pickup(40, 1000, 0.9, 1);
  wooo(-30, 1.);
  weee(-15, 1.);
  shoot(1, 3250, 1250, 1000);
}





void norcal_skills_auton(){
  pros::lcd::set_text(1, "Autonomous");
  pros::lcd::set_text(2, "Running");
  expand(false);
  indexer.set_value(false);
  //go to roller
  weee(14, 1.);
  //spin roller
  roll(200, -1);

  /*setRollerRed();*/

  //back off roller
  weee(-14, 1.);
  //turn to first disk
  wooo(135, 1.);
  //drive toward first disk 
  weee(17, 1.);
  //pick up first disk
  pickup(38, 1000, 0.6, 1);
  //go forward to roller at angle
  weee(30, 1.);
  //turn to face roller
  wooo(92, 1.);
  //go to roller and touch 
  weee(25, 1.);
  weee(15, 0.5);
  //spin roller
  roll(200, 1);
  /*setRollerRed();*/

  //back off roller
  weee(-15, 1.);
  //spin back off in the direction of feeding area
  wooo(-45, 1.);
  // go to drive area 
  weee(85, 1.); //sqrt of 8  -> 38; sqrt of  5 -> 30 -> 28 PROPORTIONS
  //swing into the high goal
  //chassis.set_swing_pid(LEFT_SWING, 90, -1*DRIVE_SPEED);
  // turn toward high goal
  wooo(90, 1.);
  // move toward the goal
  weee(-100, 1.);
  // turn to angle at goal
  wooo(80, 1);
  // move posted on the block to shoot
  weee(-30, 1);
  //shoot at goal
  shoot(0.85, 1650, 650, 500);  ///FIX - FIXED :)  

  // start the intake
  intake_roller.move_velocity(200);

  // drive up to allow feeded disk to come in - 1
  weee(40, 0.8);
  //pause to pick up
  pros::delay(250);
  //drive away from disks
  weee(-40, 0.8);
  //pause to between picks
  pros::delay(250);
  // drive up to allow feeded disk to come in - 2
  weee(40, 0.8);
  //pause to pick up
  pros::delay(250);
  //drive away from disks
  weee(-40, 0.8);
  //pause to between picks
  pros::delay(250);
  // drive up to allow feeded disk to come in - 3
  weee(40, 0.8);
  //pause to pick up
  pros::delay(250);
  //drive down to shoot
  weee(-40, 0.8);
  //shoot at goal
  shoot(0.85, 1650, 650, 500);


  /*
  // drive up to allow feeded disk to come in - 4
  weee(12, 1.);
  //drive down to take in feeded disk
  weee(-12, 1.);
  // drive up to allow feeded disk to come in - 5
  weee(12, 1.);
  //drive down to take in feeded disk
  weee(-12, 1.);
  // drive up to allow feeded disk to come in - 6
  weee(12, 1.);
  //drive down to take in feeded disk
  weee(-12, 1.);
  //shoot at goal
  shoot(0.85, 2500, 825, 825);

  // drive up to allow feeded disk to come in - 7
  weee(12, 1.);
  //drive down to take in feeded disk
  weee(-12, 1.);
  // drive up to allow feeded disk to come in - 8
  weee(12, 1.);
  //drive down to take in feeded disk
  weee(-12, 1.);
  // drive up to allow feeded disk to come in - 9
  weee(12, 1.);
  //drive down to take in feeded disk
  weee(-12, 1.);
  //shoot at goal
  shoot(0.85, 2500, 825, 825); 
  
  // drive up to allow feeded disk to come in - 10
  weee(12, 1.);
  //drive down to take in feeded disk
  weee(-12, 1.);
  // drive up to allow feeded disk to come in - 11
  weee(12, 1.);
  //drive down to take in feeded disk
  weee(-12, 1.);
  // drive up to allow feeded disk to come in - 12
  weee(12, 1.);
  //drive down to take in feeded disk
  weee(-12, 1.);
  //shoot at goal
  shoot(0.85, 2500, 825, 825);

  // turn off the intake
  intake_roller.move_velocity(0);

  //turn toward rollers
  wooo(45, 1.);
  //drive and pickup disks

  //turn toward other side
  chassis.set_turn_pid(180+45, TURN_SPEED);
  chassis.wait_drive(); 
  //drive to those three disks
  chassis.set_drive_pid(52, DRIVE_SPEED);
  chassis.wait_drive();
  //pickup the three disks
  pickup(40, 2000, 0.4, 1);
  chassis.wait_drive();
  chassis.set_turn_pid(180+43.5, TURN_SPEED);
  chassis.wait_drive();
  pickup(35, 2000, 0.4, 1);
  chassis.wait_drive();
  chassis.set_drive_pid(40, DRIVE_SPEED);
  chassis.wait_drive();
  pickup(35, 2000, 0.4, 1);
  chassis.wait_drive();
  */
}





void comp_auton() {
  pros::lcd::set_text(1, "Autonomous");
  pros::lcd::set_text(2, "Running");
  indexer.set_value(false);
  chassis.set_drive_pid(12, DRIVE_SPEED);
  chassis.wait_drive();
  roll(150, -1);
  chassis.set_drive_pid(-12, DRIVE_SPEED);
  chassis.wait_drive();
  chassis.set_turn_pid(-126, TURN_SPEED);
  chassis.wait_drive();
  chassis.set_drive_pid(100, DRIVE_SPEED);
  chassis.wait_drive();
  pickup(30, 1900, 1, 1);
  chassis.set_turn_pid(-23, TURN_SPEED);
  chassis.wait_drive();
  chassis.set_drive_pid(-13.75, DRIVE_SPEED);
  chassis.wait_drive();
  shoot(1, 3200, 1200, 900); 
}


/*
1. roller #1
2. turn 135 deg right 
3. pick up 2nd disc from corner
4. forward + turn to roller
5. spin roller #2
6. back up
7. turn flywheel toward goal
8. go to shooting spot
9. rev up, index, shoot flywheel
10. turn up field toward disc up one tile from it
11. turn and grab 3 in a row discs
12. turn and go to next shooting spot for other goal
13. shoot all 3*/

void skills_auton(){
  pros::lcd::set_text(1, "Autonomous");
  pros::lcd::set_text(2, "Running");
  expand(false);
  indexer.set_value(false);
  //go to roller
  chassis.set_drive_pid(12, DRIVE_SPEED);
  chassis.wait_drive();
  //spin roller
  roll(100, -1);
  //back off roller
  chassis.set_drive_pid(-12, DRIVE_SPEED);
  chassis.wait_drive(); 
  //turn to first disk
  chassis.set_turn_pid(135, TURN_SPEED);
  chassis.wait_drive();
  //drive toward first disk 
  chassis.set_drive_pid(15, DRIVE_SPEED);
  chassis.wait_drive(); 
  //pick up first disk
  pickup(40, 2000, 0.5, 1);
  //go forward to roller at angle
  chassis.set_drive_pid(30, DRIVE_SPEED);
  chassis.wait_drive();
  //turn to face roller
  chassis.set_turn_pid(80, TURN_SPEED);
  chassis.wait_drive();
  //go to roller and touch 
  chassis.set_drive_pid(30, DRIVE_SPEED);
  chassis.wait_drive();
  chassis.set_drive_pid(10, 0.5*DRIVE_SPEED);
  chassis.wait_drive();
  //spin roller
  roll(100, 1);
  //back off roller
  chassis.set_drive_pid(-10, DRIVE_SPEED);
  chassis.wait_drive();
  //spin back off  
  chassis.set_turn_pid(10, TURN_SPEED);
  chassis.wait_drive();
  //drive toward goal 
  chassis.set_drive_pid(-50, DRIVE_SPEED);
  chassis.wait_drive();
  //angle to shoot at goal  
  chassis.set_turn_pid(15, TURN_SPEED);
  chassis.wait_drive(); 
  //shoot at goal
  shoot(0.85, 2500, 825, 825);
  //turn toward other side
  chassis.set_turn_pid(-90, TURN_SPEED);
  chassis.wait_drive(); 
  //drive toward other side
  chassis.set_drive_pid(48, DRIVE_SPEED);
  chassis.wait_drive();
  //turn angled to three disks in a row
  chassis.set_turn_pid(45, TURN_SPEED);
  chassis.wait_drive();
  //pick up those three disks
  pickup(150, 7500, 1, 1);
  //keep going toward roller
  chassis.set_drive_pid(22, DRIVE_SPEED);
  chassis.wait_drive();
  //swing into roller
  chassis.set_swing_pid(RIGHT_SWING, 45, SWING_SPEED);
  chassis.wait_drive();
  //drive up to roller properly
  chassis.set_drive_pid(12, DRIVE_SPEED);
  chassis.wait_drive();
  //spin roller 3
  roll(200, 1);
  //back off roller 3
  chassis.set_drive_pid(-12, DRIVE_SPEED);
  chassis.wait_drive();
  //turn to roller 4
  chassis.set_turn_pid(-135, TURN_SPEED);
  chassis.wait_drive();
  //drive to roller 4
  chassis.set_drive_pid(24, DRIVE_SPEED);
  chassis.wait_drive();
  //turn to roller 4 again
  chassis.set_turn_pid(45, TURN_SPEED);
  chassis.wait_drive();
  //drive up to roller 4
  chassis.set_drive_pid(12, DRIVE_SPEED);
  chassis.wait_drive();
  //spin roller 4
  roll(200, 1);
  //back roller off 4
  chassis.set_drive_pid(-24, DRIVE_SPEED);
  chassis.wait_drive();
  //turn to red goal
  chassis.set_turn_pid(90, TURN_SPEED);
  chassis.wait_drive();
  //drive up to red goal
  chassis.set_drive_pid(-20, DRIVE_SPEED);
  chassis.wait_drive();
  //shoot on red goal
  shoot(0.75, 2500, 825, 825);
  //drive back to corner w roller 3 and 4
  chassis.set_drive_pid(36, DRIVE_SPEED);
  chassis.wait_drive();
  //turn to the middle of the field and expand
  chassis.set_turn_pid(60, TURN_SPEED);
  chassis.wait_drive();
  expand(true);
}

void skills_skillsfr() {
  pros::lcd::set_text(1, "Autonomous");
  pros::lcd::set_text(2, "Running");
  expand(false);
  indexer.set_value(false);
  //go to roller
  chassis.set_drive_pid(14, DRIVE_SPEED);
  chassis.wait_drive();
  //spin roller
  roll(250, -1);
  //back off roller
  chassis.set_drive_pid(-14, DRIVE_SPEED);
  chassis.wait_drive(); 
  //turn to first disk
  chassis.set_turn_pid(135, TURN_SPEED);
  chassis.wait_drive();
  //drive toward first disk 
  chassis.set_drive_pid(17, DRIVE_SPEED);
  chassis.wait_drive(); 
  //pick up first disk
  pickup(38, 2000, 0.35, 1);
  //go forward to roller at angle
  chassis.set_drive_pid(30, DRIVE_SPEED);
  chassis.wait_drive();
  //turn to face roller
  chassis.set_turn_pid(92, TURN_SPEED);
  chassis.wait_drive();
  //go to roller and touch 
  chassis.set_drive_pid(25, DRIVE_SPEED);
  chassis.wait_drive();
  chassis.set_drive_pid(10, 0.5*DRIVE_SPEED);
  chassis.wait_drive();
  //spin roller
  roll(250, 1);
  //back off roller
  chassis.set_drive_pid(-10, DRIVE_SPEED);
  chassis.wait_drive();
  //spin back off  
  chassis.set_turn_pid(10, TURN_SPEED);
  chassis.wait_drive();
  //drive toward goal 
  chassis.set_drive_pid(-45, DRIVE_SPEED);
  chassis.wait_drive();
  //angle to shoot at goal  
  chassis.set_turn_pid(3, TURN_SPEED);
  chassis.wait_drive(); 
  //shoot at goal
  shoot(0.76, 2050, 750, 700);
  //turn toward other side
  chassis.set_turn_pid(180+45, TURN_SPEED);
  chassis.wait_drive(); 
  //drive to those three disks
  chassis.set_drive_pid(52, DRIVE_SPEED);
  chassis.wait_drive();
  //pickup the three disks
  pickup(40, 2000, 0.4, 1);
  chassis.wait_drive();
  chassis.set_turn_pid(180+43.5, TURN_SPEED);
  chassis.wait_drive();
  pickup(35, 2000, 0.4, 1);
  chassis.wait_drive();
  chassis.set_drive_pid(40, DRIVE_SPEED);
  chassis.wait_drive();
  pickup(35, 2000, 0.4, 1);
  chassis.wait_drive();
  //turn to shoot
  chassis.set_turn_pid(180+43.5+82.5, TURN_SPEED);
  chassis.wait_drive();
  //shoot 3 in red
  shoot(0.9, 1400, 500, 375);
  //turn
  chassis.set_turn_pid(180+47, TURN_SPEED);
  chassis.wait_drive();
  //knock over 3 disks
  //chassis.set_drive_pid(80, DRIVE_SPEED);
  //chassis.wait_drive();
  //pros::delay(500);
  //run over 3 disks
  pickup(215, 2000, 1, -1);
  chassis.wait_drive();
  chassis.set_swing_pid(RIGHT_SWING, 178, DRIVE_SPEED);
  chassis.wait_drive();
  chassis.set_drive_pid(22.5, DRIVE_SPEED*0.8);
  chassis.wait_drive();
  roll(300, 1);
  chassis.set_drive_pid(-20, DRIVE_SPEED*0.8);
  chassis.wait_drive();
  chassis.set_drive_pid(-70, DRIVE_SPEED);
  chassis.set_turn_pid(270, TURN_SPEED);
  chassis.wait_drive();
  chassis.set_drive_pid(70, DRIVE_SPEED);
  chassis.wait_drive();
  chassis.set_drive_pid(20, DRIVE_SPEED*0.6);
  chassis.wait_drive();
  roll(250, 1);
  chassis.set_drive_pid(-20, DRIVE_SPEED);
  chassis.wait_drive();
  chassis.set_turn_pid(225, TURN_SPEED);
  chassis.wait_drive();
  chassis.set_drive_pid(-150, DRIVE_SPEED);
  chassis.wait_drive();
  pros::delay(1500);
  //shoot(0.9, 2250, 800, 750);
  expand(true);
  pros::delay(100);
  expand(true);
  pros::delay(100);
  expand(true);
  pros::delay(100);
  expand(true);
  pros::delay(100);
  expand(true);
  pros::delay(1000);
  chassis.set_drive_pid(130, DRIVE_SPEED);
  chassis.wait_drive();
  chassis.set_turn_pid(270, TURN_SPEED);
  chassis.wait_drive();
  chassis.set_drive_pid(10, DRIVE_SPEED);
  chassis.wait_drive();
}


void skills_auton2(){
  pros::lcd::set_text(1, "Autonomous");
  pros::lcd::set_text(2, "Running");
  expand(false);
  indexer.set_value(false);
  //go to roller
  chassis.set_drive_pid(12, DRIVE_SPEED);
  chassis.wait_drive();
  //spin roller
  roll(210, 1);
  //back off roller
  chassis.set_drive_pid(-12, DRIVE_SPEED);
  chassis.wait_drive(); 
  //turn to first disk
  chassis.set_turn_pid(135, TURN_SPEED);
  chassis.wait_drive();
  //drive toward first disk 
  chassis.set_drive_pid(17, DRIVE_SPEED);
  chassis.wait_drive(); 
  //pick up first disk
  pickup(38, 2000, 0.35, 1);
  //go forward to roller at angle
  chassis.set_drive_pid(30, DRIVE_SPEED);
  chassis.wait_drive();
  //turn to face roller
  chassis.set_turn_pid(83, TURN_SPEED);
  chassis.wait_drive();
  //go to roller and touch 
  chassis.set_drive_pid(25, DRIVE_SPEED);
  chassis.wait_drive();
  chassis.set_drive_pid(10, 0.5*DRIVE_SPEED);
  chassis.wait_drive();
  //spin roller
  roll(250, 1);
  //back off roller
  chassis.set_drive_pid(-10, DRIVE_SPEED);
  chassis.wait_drive();
  //spin back off  
  chassis.set_turn_pid(10, TURN_SPEED);
  chassis.wait_drive();
  //drive toward goal 
  chassis.set_drive_pid(-45, DRIVE_SPEED);
  chassis.wait_drive();
  //angle to shoot at goal  
  chassis.set_turn_pid(2, TURN_SPEED);
  chassis.wait_drive(); 
  //shoot at goal
  shoot(0.77, 2500, 825, 825);
  //turn toward other side
  chassis.set_turn_pid(180+45, TURN_SPEED);
  chassis.wait_drive(); 
  //drive to those three disks
  chassis.set_drive_pid(52, DRIVE_SPEED);
  chassis.wait_drive();
  //pickup the three disks
  pickup(60, 2500, 0.4, 1);
  chassis.wait_drive();
  chassis.set_turn_pid(180+43.5, TURN_SPEED);
  chassis.wait_drive();
  pickup(60, 2500, 0.4, 1);
  chassis.wait_drive();
  pickup(60, 2500, 0.4, 1);
  chassis.wait_drive();
  //expand(true);
}


void z_skills_auton() {
  pros::lcd::set_text(1, "Autonomous");
  pros::lcd::set_text(2, "Running");
  expand(false);
  indexer.set_value(false);
  //go to roller
  weee(12, 1.);
  weee(10, 0.5);
  //spin roller
  roll(250, 1);
  //back off roller
  weee(-12, 1.); 
  //turn to first disk
  wooo(135, 1.);
  //drive toward first disk 
  weee(17, 1.);
  //pick up first disk
  pickup(38, 2000, 0.35, 1);
  //go forward to roller at angle
  weee(30, 1.);
  //turn to face roller
  wooo(83, 1.);
  //go to roller and touch
  weee(25, 1.);
  weee(10, 0.5);
  //spin roller
  roll(250, 1);
  //back off roller
  weee(-10, 1.);
  //spin back off  
  wooo(10, 1.);
  //drive toward goal 
  weee(-45, 1.);
  //angle to shoot at goal  
  wooo(3, 1.);
  //shoot at goal
  shoot(0.77, 2600, 800, 725);
  //turn toward other side
  wooo(180+45, 1.);
  //drive to those three disks
  weee(52, 1.);
  //pickup the three disks
  pickup(40, 2500, 0.4, 1);
  chassis.wait_drive();
  wooo(180+43.5, 1.);
  pickup(35, 2500, 0.4, 1);
  chassis.wait_drive();
  chassis.set_drive_pid(25, DRIVE_SPEED);
  pickup(40, 2500, 0.4, 1);
  chassis.wait_drive();
  //keep going toward roller
  weee(22, 1.);
  //swing into roller
  chassis.set_swing_pid(RIGHT_SWING, 45, SWING_SPEED);
  chassis.wait_drive();
  //drive up to roller properly
  weee(12, 1.);
  weee(10, 0.5);
  //spin roller 3
  roll(200, 1);
  //back off roller 3
  weee(-12, 1.);
  //turn to roller 4
  wooo(-135, 1.);
  //drive to roller 4
  weee(24, 1.);
  //turn to roller 4 again
  wooo(45, 1.);
  //drive up to roller 4
  weee(12, 1.);
  weee(10, 0.5);
  //spin roller 4
  roll(200, 1);
  //back roller off 4
  weee(-24, 1.);
  //turn to red goal
  wooo(90, 1.);
  //drive up to red goal
  weee(-20, 1.);
  //shoot on red goal
  shoot(0.75, 2500, 825, 825);
  //drive back to corner w roller 3 and 4
  weee(36, 1.);
  //turn to the middle of the field
  wooo(60, 1.);
  //EXPANDS
  expand(true);
}


