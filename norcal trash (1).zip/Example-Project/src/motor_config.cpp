#include "main.h"

pros::Motor intake_roller(18, MOTOR_GEARSET_18, true, MOTOR_ENCODER_DEGREES);
pros::Motor flywheel(6, MOTOR_GEARSET_06, true, MOTOR_ENCODER_DEGREES);
//pros::Motor expansion(4, MOTOR_GEARSET_36, true, MOTOR_ENCODER_ssdDEGREES);

pros::ADIDigitalOut indexer('H'); // ex template for pistons
pros::ADIDigitalOut expansion('A');

//pros::Distance dist_sensor(19);

//pros::Optical optic_sensor(13);

pros::IMU inert(11);