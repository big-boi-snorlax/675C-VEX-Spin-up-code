#include "main.h"

bool switch_bool = true;
bool indexer_bool = true;
int curr_indexer = 0;
double max_vel = 600;
double idle_speed = 75;

/*
void default_constants2() {
  chassis.set_slew_min_power(80, 80);
  chassis.set_slew_distance(7, 7);
  chassis.set_pid_constants(&chassis.headingPID, 11, 0, 19, 0);
  chassis.set_pid_constants(&chassis.forward_drivePID, 0.45, 0, 1.8, 0);
  chassis.set_pid_constants(&chassis.backward_drivePID, 0.45, 0, 1.8, 0);
  chassis.set_pid_constants(&chassis.turnPID, 5, 0.003, 29, 15);
  chassis.set_pid_constants(&chassis.swingPID, 7, 0, 35, 0);
// }
*/

//instantitate ur op control functions here
void fly_int_rol_control() {
  //outtake / roller backward - l1
  if (master.get_digital(pros::E_CONTROLLER_DIGITAL_L1)){
    intake_roller.move_velocity(-200);
    flywheel.move_velocity(0);
  }
  //intake / roller forward - l2
  else if (master.get_digital(pros::E_CONTROLLER_DIGITAL_L2)){
    intake_roller.move_velocity(200);
    flywheel.move_velocity(0);
  }
  //spin flywheel - r2
  else if (master.get_digital(pros::E_CONTROLLER_DIGITAL_R2)) {
    flywheel.move_velocity(600);
    intake_roller.move_velocity(0);
  }
  //stop everything - up
  else if (master.get_digital(pros::E_CONTROLLER_DIGITAL_UP)){
    flywheel.move_velocity(0);
    intake_roller.move_velocity(0);
  }
  //spin flywheel backward - down
  else if (master.get_digital(pros::E_CONTROLLER_DIGITAL_DOWN)) {
    flywheel.move_velocity(idle_speed*-1);
    intake_roller.move_velocity(0);
  }
  //regular state - intake off, idle flywheel
  else{
    intake_roller.move_velocity(0);
    flywheel.move_velocity(idle_speed);
  }
}



void intake_roller_control(){
  //outtake
  if (master.get_digital(pros::E_CONTROLLER_DIGITAL_L1)){
    intake_roller.move_velocity(-200);
    flywheel.move_velocity(0);
  }
  //intake
  else if (master.get_digital(pros::E_CONTROLLER_DIGITAL_L2)){
    intake_roller.move_velocity(200);
    flywheel.move_velocity(0);
  }
  else{
    intake_roller.move_velocity(0);
    flywheel.move_velocity(idle_speed);
  }
}

/*
void intake_control() {
  if (master.get_digital(pros::E_CONTROLLER_DIGITAL_R2)) {
    intake.move_velocity(-200*0.87);
  }
  else if (master.get_digital(pros::E_CONTROLLER_DIGITAL_LEFT)) {
    intake.move_velocity(200*0.87);
  }
  else {
    intake.move_velocity(0);
  }
}
*/

//indexer_bool: false if indexed, true if spinning first
void flywheel_control() {
  if (master.get_digital(pros::E_CONTROLLER_DIGITAL_R2)) {
      flywheel.move_velocity(600*0.8);
      //flywheel.move_velocity(max_vel);
  }
  /*
  if (master.get_digital(pros::E_CONTROLLER_DIGITAL_X)) {
    //max_vel = flywheel.get_velocity();
    //indexer_bool = false;
    indexer.set_value(true);
    pros::delay(300);
  }
  */
  //stops the flywheel
  else if (master.get_digital(pros::E_CONTROLLER_DIGITAL_UP)){
    flywheel.move_velocity(0);
  }
  //backward flywheel (only use if necessary)
  else if (master.get_digital(pros::E_CONTROLLER_DIGITAL_DOWN)) {
    flywheel.move_velocity(idle_speed*-1);
  }
  //idle flywheel at 75 rpm
  else {
    //indexer.set_value(false);
    flywheel.move_velocity(idle_speed);
  }
}

void indexer_control() {
  //0 state is contracted, 1 state is expanded NOT IMPORTANT ANYMORE
  if (master.get_digital(pros::E_CONTROLLER_DIGITAL_X)) {
    indexer.set_value(true);
    pros::delay(300);
  }
  else {
    indexer.set_value(false);
  }
}

void flywheel_triple() {
  if (master.get_digital(pros::E_CONTROLLER_DIGITAL_A)) {
    //flywheel.move_voltage(6000);
    flywheel.move_velocity(600);
    pros::delay(1400);
    indexer.set_value(true);
    pros::delay(350);
    indexer.set_value(false);
    pros::delay(150);
    indexer.set_value(true);
    pros::delay(350);
    indexer.set_value(false);
    pros::delay(50);
    flywheel.move_velocity(600);
    pros::delay(100);
    indexer.set_value(true);
    pros::delay(350);
    indexer.set_value(false);
    flywheel.move_velocity(idle_speed);
  }
}

/*
void fly_index_control() {
  if (master.get_digital(pros::E_CONTROLLER_DIGITAL_RIGHT)) {
    flywheel.move_velocity(600);
  }
  else {
    flywheel.move_velocity(0);
  }
  if (master.get_digital(pros::E_CONTROLLER_DIGITAL_X)) {
    indexer.set_value(true);
    pros::delay(2000);
  }
  else {
    indexer.set_value(false);
  }
}
*/


void expansion_control() {
  if (master.get_digital(pros::E_CONTROLLER_DIGITAL_Y)) {
    expansion.set_value(true);
    pros::delay(5000);
  }
  else {
    expansion.set_value(false);
  }
}



void indexer_macro_control() {
  //
}

/*
void flywheel_control2() {
  if (master.get_digital(pros::E_CONTROLLER_DIGITAL_LEFT)) {
    if (flywheel.get_actual_velocity()!=0){
      flywheel.move_velocity(0);
    }
    else{
      flywheel.move_velocity(200);
    }

  }

}
*/

/*
void pusher_control() {
  if (master.get_digital(pros::E_CONTROLLER_DIGITAL_R2)) {
    pushpush.move_velocity(1);
  }
  else {
    pushpush.move_velocity(0);
  }
}
*/

void switch_drive() {
  if (master.get_digital_new_press(pros::E_CONTROLLER_DIGITAL_A)) {
    // true if forward is intake
    if (switch_bool == true) {
//      chassis.arcade_flipped(ez::SPLIT);
      //reverse_drive();
      switch_bool = false;
    }
    // false is forward is flywheel
    else if (switch_bool == false) {
//      chassis.arcade_standard(ez::SPLIT);
      //reverse_drive();
      switch_bool = true;
    }
  }
}


void op_control(){
  fly_int_rol_control();
  //intake_roller_control();
  //intake_control();
  //flywheel_control();
  expansion_control();
  indexer_control();
  flywheel_triple();
  //fly_index_control();
  //indexer_macro_control();
  //flywheel_control2();
  //switch_drive();
  //pusher_control();
  //need this to have op control thingy
}
