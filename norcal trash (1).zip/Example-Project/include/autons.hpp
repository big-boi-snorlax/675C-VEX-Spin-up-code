#pragma once

#include "EZ-Template/drive/drive.hpp"

extern Drive chassis;

void roller_only();
void comp_auton();
void blue_comp_auton();
void red_comp_auton();
void blue_right_comp_auton();
void red_right_comp_auton();
void norcal_skills_auton();
void new_fr_skills_auton();
void skills_auton();
void skills_skillsfr();
void skills_autonfsrealone();
void skills_auton2();
void z_skills_auton();

void default_constants();