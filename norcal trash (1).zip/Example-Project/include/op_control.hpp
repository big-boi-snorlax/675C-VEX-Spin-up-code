#include "api.h"

void op_control();

int driveLockSwitch();
int indexSwitch();
void drive_lock();
void ind_rot();

void fly_int_rol_control();
void intake_roller_control();
void flywheel_control();
void indexer_control();
void flywheel_triple();
void expansion_control();

extern pros:: Task drive_lock_task();
extern pros::Task mogo_control_task();

extern pros:: Task index_macros();
extern pros:: Task flyWheelTask();
