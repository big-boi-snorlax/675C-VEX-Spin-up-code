#include "api.h"

extern pros:: Motor intake_roller;

extern pros:: Motor flywheel;

extern pros:: ADIDigitalOut indexer;

extern pros:: ADIDigitalOut expansion;

extern pros:: Motor roller;

//extern pros:: Distance dist_sensor;

//extern pros:: Optical optic_sensor;

extern pros:: IMU inert;